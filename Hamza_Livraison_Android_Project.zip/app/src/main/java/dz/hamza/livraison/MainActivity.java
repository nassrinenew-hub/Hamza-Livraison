package dz.hamza.livraison;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, historyBox;
    TextView status, distanceText, priceText, totalsText, gpsText;
    Button startBtn, stopBtn;
    EditText p1Input,p2Input,p3Input,extraInput;
    LocationManager locationManager;
    Location lastLocation;
    double meters=0;
    boolean running=false;
    int countPoints=0;
    SharedPreferences prefs;
    ArrayList<String> history = new ArrayList<>();
    ArrayList<Integer> historyPrices = new ArrayList<>();
    ArrayList<Double> historyKm = new ArrayList<>();
    int p1=150,p2=200,p3=300,extra=30;
    final int REQ=42;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("hl",MODE_PRIVATE);
        p1=prefs.getInt("p1",150); p2=prefs.getInt("p2",200); p3=prefs.getInt("p3",300); extra=prefs.getInt("extra",30);
        loadHistory(); buildUI(); render();
        locationManager=(LocationManager)getSystemService(Context.LOCATION_SERVICE);
    }
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    TextView text(String s,int size,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(20,55,52));
        if(bold)t.setTypeface(null,1); t.setGravity(Gravity.CENTER); t.setPadding(dp(4),dp(5),dp(4),dp(5)); return t;
    }
    Button button(String s,int color){
        Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color)); return b;
    }
    LinearLayout card(){
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(14),dp(12),dp(14),dp(12));
        c.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(dp(12),dp(7),dp(12),dp(7)); c.setLayoutParams(lp); return c;
    }
    EditText input(String hint,int value){
        EditText e=new EditText(this); e.setSingleLine(true); e.setInputType(2); e.setHint(hint); e.setText(""+value); return e;
    }
    void buildUI(){
        ScrollView scroll=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(242,247,246)); root.setPadding(0,0,0,dp(15));
        TextView head=text("🛵 Hamza Livraison\\nحساب المسافة وسعر الكورسة",23,true); head.setTextColor(Color.WHITE); head.setBackgroundColor(Color.rgb(15,118,110)); head.setPadding(dp(12),dp(25),dp(12),dp(25)); root.addView(head);
        LinearLayout c=card();
        status=text("ما كاش كورسة جارية",16,true); c.addView(status);
        distanceText=text("0.00 كلم",34,true); distanceText.setTextColor(Color.rgb(19,78,74)); c.addView(distanceText);
        priceText=text("150 دج",28,true); priceText.setTextColor(Color.rgb(15,118,110)); c.addView(priceText);
        gpsText=text("اسمح للتطبيق باستعمال الموقع GPS.",13,false); c.addView(gpsText);
        startBtn=button("▶ ابدأ الكورسة",Color.rgb(15,118,110)); c.addView(startBtn);
        stopBtn=button("■ أنهِ الكورسة",Color.rgb(185,28,28)); c.addView(stopBtn);
        Button reset=button("إعادة ضبط المسافة",Color.rgb(71,85,105)); c.addView(reset);
        root.addView(c);
        startBtn.setOnClickListener(v->startTrip()); stopBtn.setOnClickListener(v->stopTrip());
        reset.setOnClickListener(v->{if(!running){meters=0;lastLocation=null;render();}});
        LinearLayout settings=card(); settings.addView(text("⚙️ إعدادات التسعيرة (دج)",18,true));
        p1Input=input("حتى 2 كلم",p1); p2Input=input("أكثر من 2 حتى 5 كلم",p2); p3Input=input("أكثر من 5 حتى 8 كلم",p3); extraInput=input("لكل كلم إضافي بعد 8",extra);
        settings.addView(text("حتى 2 كلم",13,false));settings.addView(p1Input);
        settings.addView(text("أكثر من 2 حتى 5 كلم",13,false));settings.addView(p2Input);
        settings.addView(text("أكثر من 5 حتى 8 كلم",13,false));settings.addView(p3Input);
        settings.addView(text("لكل كلم إضافي بعد 8",13,false));settings.addView(extraInput);
        Button save=button("حفظ الأسعار",Color.rgb(15,118,110)); settings.addView(save);
        save.setOnClickListener(v->{p1=val(p1Input,p1);p2=val(p2Input,p2);p3=val(p3Input,p3);extra=val(extraInput,extra);prefs.edit().putInt("p1",p1).putInt("p2",p2).putInt("p3",p3).putInt("extra",extra).apply();render();Toast.makeText(this,"تحفظت الأسعار",Toast.LENGTH_SHORT).show();});
        root.addView(settings);
        LinearLayout hist=card(); hist.addView(text("📊 سجل الكورسات والمداخيل",18,true));
        totalsText=text("",16,true);hist.addView(totalsText);
        historyBox=new LinearLayout(this);historyBox.setOrientation(LinearLayout.VERTICAL);hist.addView(historyBox);
        Button clear=button("مسح السجل",Color.rgb(185,28,28));hist.addView(clear);
        clear.setOnClickListener(v->{history.clear();historyPrices.clear();historyKm.clear();saveHistory();render();});
        root.addView(hist);
        TextView note=text("ملاحظة: المسافة تعتمد على دقة GPS. النسخة الحالية تحسب المسافة الفعلية من نقاط الموقع، ولا تعرض خريطة أو مساراً مرسوماً بعد.",12,false); note.setPadding(dp(18),dp(8),dp(18),dp(8));root.addView(note);
        scroll.addView(root);setContentView(scroll);
    }
    int val(EditText e,int fallback){try{return Math.max(0,Integer.parseInt(e.getText().toString().trim()));}catch(Exception ex){return fallback;}}
    int price(double km){if(km<=2)return p1;if(km<=5)return p2;if(km<=8)return p3;return p3+(int)Math.ceil(km-8)*extra;}
    void render(){
        distanceText.setText(String.format(Locale.US,"%.2f كلم",meters/1000.0));
        priceText.setText(price(meters/1000.0)+" دج");
        status.setText(running?"الكورسة راهي جارية":"ما كاش كورسة جارية");
        startBtn.setEnabled(!running);stopBtn.setEnabled(running);
        int total=0;for(int n:historyPrices)total+=n;
        totalsText.setText("عدد الكورسات: "+history.size()+"     مجموع المداخيل: "+total+" دج");
        historyBox.removeAllViews();
        if(history.isEmpty())historyBox.addView(text("مازال ما سجلت حتى كورسة.",13,false));
        for(int i=0;i<history.size();i++) historyBox.addView(text(history.get(i)+" — "+String.format(Locale.US,"%.2f كلم",historyKm.get(i))+" — "+historyPrices.get(i)+" دج",13,false));
    }
    void startTrip(){
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},REQ);return;
        }
        beginGPS();
    }
    void beginGPS(){
        try{
            running=true;meters=0;lastLocation=null;countPoints=0;render();gpsText.setText("نستناو إشارة GPS…");
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1500,2,new LocationListener(){
                @Override public void onLocationChanged(Location loc){
                    if(!running)return;
                    if(loc.hasAccuracy()&&loc.getAccuracy()>60){gpsText.setText("إشارة GPS ضعيفة، الدقة "+(int)loc.getAccuracy()+" م");return;}
                    if(lastLocation!=null){
                        float d=lastLocation.distanceTo(loc); long dt=Math.max(1,(loc.getTime()-lastLocation.getTime())/1000);
                        if(d>=4 && d<Math.max(100,dt*45)){meters+=d;countPoints++;}
                    }
                    lastLocation=loc;gpsText.setText("GPS يخدم — الدقة "+(loc.hasAccuracy()?(int)loc.getAccuracy():0)+" م");render();
                }
                @Override public void onProviderEnabled(String p){}
                @Override public void onProviderDisabled(String p){gpsText.setText("فعّل GPS من إعدادات الهاتف.");}
                @Override public void onStatusChanged(String p,int s,android.os.Bundle x){}
            });
        }catch(SecurityException e){running=false;gpsText.setText("ما قدرناش نوصلو للموقع.");render();}
    }
    void stopTrip(){
        if(!running)return;running=false;
        try{locationManager.removeUpdates((LocationListener)null);}catch(Exception ignored){}
        double km=meters/1000.0;
        if(km>0.01){
            String date=new SimpleDateFormat("dd/MM HH:mm",Locale.getDefault()).format(new Date());
            history.add(0,date);historyKm.add(0,km);historyPrices.add(0,price(km));saveHistory();
        }
        lastLocation=null;gpsText.setText(km>0.01?"تسجلت الكورسة.":"المسافة قصيرة وما تسجلتش.");render();
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){
        super.onRequestPermissionsResult(r,p,g);
        if(r==REQ&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)beginGPS();
        else Toast.makeText(this,"لازم تسمح بالوصول للموقع حتى يحسب المسافة.",Toast.LENGTH_LONG).show();
    }
    void saveHistory(){
        StringBuilder s=new StringBuilder();
        for(int i=0;i<history.size();i++)s.append(history.get(i)).append("|").append(historyKm.get(i)).append("|").append(historyPrices.get(i)).append("\\n");
        prefs.edit().putString("history",s.toString()).apply();
    }
    void loadHistory(){
        String raw=prefs.getString("history","");
        for(String line:raw.split("\\n")){if(line.trim().isEmpty())continue;String[] a=line.split("\\|");if(a.length==3)try{history.add(a[0]);historyKm.add(Double.parseDouble(a[1]));historyPrices.add(Integer.parseInt(a[2]));}catch(Exception ignored){}}
    }
}
